# uTorrent Puppet Module for Boxen

Install uTorrent (Bittorrent client) through Github Boxen.

[![Build Status](https://travis-ci.org/nonsense/puppet-utorrent.png)](https://travis-ci.org/nonsense/puppet-utorrent)

## Usage

```puppet
include utorrent
```

## Required Puppet Modules

* boxen

